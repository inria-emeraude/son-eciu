#include "MyDsp.h"

#define AUDIO_OUTPUTS 1

#define MULT_16 32767

MyDsp::MyDsp() : 
AudioStream(AUDIO_OUTPUTS, new audio_block_t*[AUDIO_OUTPUTS]),
sawtooth(AUDIO_SAMPLE_RATE_EXACT),
echo(AUDIO_SAMPLE_RATE_EXACT,10000),
LFO(AUDIO_SAMPLE_RATE_EXACT)
{
  echo.setDel(10000);
  echo.setFeedback(0.5);
  gain = 0.5;
  freq = 440;
  LFO.setFrequency(6);
}

MyDsp::~MyDsp(){}

// set sine wave frequency
void MyDsp::setFreq(float f){
  freq = f;
}

void MyDsp::setGain(float g){
  gain = g*g;
}

void MyDsp::update(void) {
  audio_block_t* outBlock[AUDIO_OUTPUTS];
  for (int channel = 0; channel < AUDIO_OUTPUTS; channel++) {
    outBlock[channel] = allocate();
    if (outBlock[channel]) {
      for (int i = 0; i < AUDIO_BLOCK_SAMPLES; i++) {
        float sampleLFO = LFO.tick();
        sawtooth.setFrequency(freq * (1 + (sampleLFO/10.0)));
        float currentSample = echo.tick(sawtooth.tick()*2 - 1)*0.5*gain;
        currentSample = max(-1,min(1,currentSample));
        int16_t val = currentSample*MULT_16;
        outBlock[channel]->data[i] = val;
      }
      transmit(outBlock[channel], channel);
      release(outBlock[channel]);
    }
  }
}

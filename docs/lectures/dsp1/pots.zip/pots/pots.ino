#include <Audio.h>
#include "MyDsp.h"

MyDsp myDsp;
AudioOutputI2S out;
AudioControlSGTL5000 audioShield;
AudioConnection patchCord0(myDsp,0,out,0);
AudioConnection patchCord1(myDsp,0,out,1);

void setup() {
  AudioMemory(2);
  audioShield.enable();
  audioShield.volume(0.5);
  pinMode(0, INPUT);
}

void loop() {
  int pot0 = analogRead(A0);
  int pot1 = analogRead(A2);

  float f = pot0/1023.0*1950.0 + 50.0;
  float g = pot1/1023.0;
  myDsp.setFreq(f);
  myDsp.setGain(g);
}

/**
 * @file MyDsp.h
 */
#ifndef __MYDSP_TEENSY_H__
#define __MYDSP_TEENSY_H__

#include "Arduino.h"
#include "AudioStream.h"
#include "Audio.h"

// From MyDsp library
#include "Noise.h"

// Custom code
#include "Biquad.h"


/**
 * Custom DSP class implementing an audio callback
 */
class MyDsp : public AudioStream
{
public:
    /**
     * Biquad filter that will be used.
     */
    Biquad biquad;
    Noise noise;

    /**
     * Default constructor for the custom DSP.
     */
    MyDsp();
    /**
     * Default destructor for the custom DSP.
     */
    ~MyDsp();

    /**
     * Audio Callback
     */
    virtual void
    update();
};

#endif/*__MYDSP_TEENSY_H__*/

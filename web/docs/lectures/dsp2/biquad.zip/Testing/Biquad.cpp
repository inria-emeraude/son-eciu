/**
 * @file Biquad.cpp
 */
#include "Biquad.h"

#include <cmath>

// pi with float precision
#define PI_F 3.14159265358979f


Biquad::Biquad(const int sr)
  : _a1(0.), _a2(0.), _b0(0.), _b1(0.), _b2(0.), w{0.,0.}, is_high_pass(false), gain_high_pass(0.0), sr(sr)
{}

void
Biquad::setCoefs(const float a1, const float a2,
                 const float b0, const float b1, const float b2)
{
    _a1 = a1;
    _a2 = a2;
    _b0 = b0;
    _b1 = b1;
    _b2 = b2;
}

void
Biquad::setBilinearCoefs(const float a0, const float a1, const float b0,
                         const float b1, const float b2, const float w1)
{
    const float c   = 1. / std::tan(w1 * 0.5 / (float)sr);
    const float csq = c * c;
    const float d   = a0 + a1*c + csq;
    const float b0d = (b0 + b1*c + b2*csq) / d;
    const float b1d = 2. * (b0 - b2*csq) / d;
    const float b2d = (b0 - b1*c + b2*csq) / d;
    const float a1d = 2. * (a0 - csq) / d;
    const float a2d = (a0 - a1*c + csq) / d;
    setCoefs(a1d, a2d, b0d, b1d, b2d);
};

void
Biquad::setResonLp(const float fc, const float Q, const float gain)
{
    is_high_pass = false;
    const float wc = 2*PI_F * fc;
    const float a0 = 1.;
    const float a1 = 1. / Q;
    const float b0 = gain;
    const float b1 = 0.;
    const float b2 = 0.;
    setBilinearCoefs(a0, a1, b0, b1, b2, wc);
}

void
Biquad::setResonHp(const float fc, const float Q, const float gain)
{
    // Set parameters just as with Lowpass
    setResonLp(fc, Q, gain);
    // But set the flag
    is_high_pass = true;
    gain_high_pass = gain;
}

void
Biquad::setResonBp(const float fc, const float Q, const float gain)
{
    is_high_pass = false;
    const float wc = 2.*PI_F * fc;
    const float a0 = 1.;
    const float a1 = 1. / Q;
    const float b0 = 0.;
    const float b1 = gain;
    const float b2 = 0.;
    setBilinearCoefs(a0, a1, b0, b1, b2, wc);
}

void
Biquad::setPeakEq(const float level , const float fx, const float b)
{
    is_high_pass = false;
    const float wx = 2.*PI_F * fx;
    const float T = 1.0 / (float)sr;
    // prewarp s-bandwidth for more accuracy in z-plane
    const float Bw = b*T / std::sin(wx*T);
    // Convert the level in dB to a linear gain
    const float g = std::pow(10., std::abs(level) / 10.);
    const float a1 = PI_F * Bw;
    const float b1 = g * a1;
    float b1s, a1s;
    if (level > 0)
    {
        b1s = b1;
        a1s = a1;
    }
    else
    {
        b1s = a1;
        a1s = b1;
    }

    setBilinearCoefs(1., a1s, 1., b1s, 1., wx);
}

float
Biquad::tick(float input)
{
    // Apply the filter
    const float w_n = input - _a1 * w[1] - _a2 * w[0];
    const float out = _b0 * w_n + _b1 * w[1] + _b2 * w[0];// y[n]
    // Update the w array with the new values
    w[0] = w[1];
    w[1] = w_n;

    if (is_high_pass)
    {
        // Invert the low pass
        return gain_high_pass * input - out;
    }
    else
    {
        return out;
    }
}


/**
 * @file Biquad.h
 */
#ifndef __BIQUAD_TEENSY_H__
#define __BIQUAD_TEENSY_H__

class Biquad
{
private:
    /**
     * Filter's poles.
     */
    float _a1, _a2;
    /**
     * Filter's zeroes.
     */
    float _b0, _b1, _b2;
    /**
     * Two previous values of the difference equation for w.
     * w[1]: w[n-1]
     * w[0]: w[n-2]
     */
    float w[2];
    /**
     * A simple flag indicating if the filter is in High pass mode.
     */
    bool is_high_pass;
    /**
     * Gain of a high pass filter (to bypass the bilinear transformation)
     */
    float gain_high_pass;
    /**
     * Sampling Rate used by the DSP;
     */
    int sr;

public:
    /**
     * Default constructor that sets all coefficients to 0.
     * @param sr Sampling rate of the DSP to use.
     */
    Biquad(const int sr);

    /**
     * Sets the coefficients of the Biquad filter.
     * @param a1 First pole
     * @param a2 Second pole
     * @param b0 Initial zero
     * @param b1 First zero
     * @param b2 Second zero
     */
    void
    setCoefs(const float a1, const float a2,
             const float b0, const float b1, const float b2);
    /**
     * Set coefficients for the Biquad filter given parameters of a Bilinear transform.
     */
    void
    setBilinearCoefs(const float a0, const float a1, const float b0,
                     const float b1, const float b2, const float w1);
    /**
     * Set parameters of the Biquad filter for a Resonant Lowpass.
     * @param fc     Cut frequency where the filter will apply.
     * @param Q      Quality factor (defines the bandwidth with Q = fc/BW).
     * @param gain   Gain applied to the signal.
     */
    void
    setResonLp(const float fc, const float Q, const float gain);
    /**
     * Set parameters of the Biquad filter for a Resonant Highpass.
     * @param fc     Cut frequency where the filter will apply.
     * @param Q      Quality factor (defines the bandwidth with Q = fc/BW).
     * @param gain   Gain applied to the signal.
     */
    void
    setResonHp(const float fc, const float Q, const float gain);
    /**
     * Set parameters of the Biquad filter for a Resonant Bandpass.
     * @param fc     Cut frequency where the filter will apply.
     * @param Q      Quality factor (defines the bandwidth with Q = fc/BW).
     * @param gain   Gain applied to the signal.
     */
    void
    setResonBp(const float fc, const float Q, const float gain);
    /**
     * Set parameters of the Biquad filter for a Peak Equalizers Filter
     * @param level  Level in dB (if negative: band reduction, if positive: band amplification)
     * @param fx     Center frequency
     * @param b      Bandwidth around fx affected
     */
    void
    setPeakEq(const float level , const float fx, const float b);

    /**
     * Applies the filter to the provided input.
     * @param input  Input signal for the Biquad filter.
     * @returns Output signal after the filter has been applied.
     */
    float
    tick(const float input);
};

#endif/*__BIQUAD_TEENSY_H__*/


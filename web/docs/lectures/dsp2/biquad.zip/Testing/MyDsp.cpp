/**
 * @file MyDsp.cpp
 */
#include "MyDsp.h"

// Both FFT and Jack use the same channel
#define AUDIO_OUTPUTS 1

#define MULT_16 32767

MyDsp::MyDsp()
  : AudioStream(AUDIO_OUTPUTS, new audio_block_t*[AUDIO_OUTPUTS]),
    biquad(AUDIO_SAMPLE_RATE_EXACT),
    noise()
{}

MyDsp::~MyDsp()
{}

void
MyDsp::update()
{
    float filtered;// Filter output
    audio_block_t* outBlock[AUDIO_OUTPUTS];

    for (int channel = 0; channel < AUDIO_OUTPUTS; ++channel)
    {
        outBlock[channel] = allocate();
        if (outBlock[channel])
        {
            for (int i = 0; i < AUDIO_BLOCK_SAMPLES; ++i)
            {
                // Generate some white noise & apply the filter
                filtered = biquad.tick(noise.tick());
                // Clamp to -1,1 and convert to a suitable DAC value
                int16_t val = max(-1,min(1,filtered))*MULT_16;
                outBlock[channel]->data[i] = val;
            }
            transmit(outBlock[channel], channel);
            release(outBlock[channel]);
        }
    }
}


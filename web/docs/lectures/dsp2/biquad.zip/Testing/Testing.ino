/**
 * Main testing file.
 * @file Testing.ino
 */
// Usual imports for teensy
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <SerialFlash.h>
// Audio stuff
#include <Audio.h>
#include "MyDsp.h"

/**
 * Electronics setup
 * - 1 Potentiometer with value connected to A0
 * - 1 button connected to port 0
 */

// Declare audio and hardware devices & connections
MyDsp myDsp;
AudioAnalyzeFFT1024 myFFT;
AudioOutputI2S out;

/// Setup audio connections
// Single channel for both outputs
AudioConnection patchCordL(myDsp, 0, out, 0);// L
AudioConnection patchCordR(myDsp, 0, out, 1);// R
// Also connect myDsp to our FFT system
AudioConnection patchCordFFT(myDsp, 0, myFFT, 0);// FFT

// Create the audio shield object to setup hardware
AudioControlSGTL5000 audioShield;

// How many bins to display
// It corresponds to roughly to 0Hz to 1.6/1.7kHz
const float n_bins = 40;

// Interaction stuff
int readButton;
bool pressingButton = false;
char selectedFilterId = 0;
float freqPot = 20.f;
int potValue = 0;

/**
 * SETUP call
 */
void
setup()
{
    // AudioShield setup
    // We use a "large" amount of memory just to be sure for the FFT computations
    // WARNING: the FFT example used 12 here
    AudioMemory(12);// This number should be at least the number of patchCords
    audioShield.enable();
    audioShield.volume(0.1);
    // FFT window algorithm setup
    myFFT.windowFunction(AudioWindowHanning1024);
    // Pins setup
    pinMode(0, INPUT);// Set the button on port 0 as INPUT
    // Serial setup
    Serial.begin(9600);
}

/**
 * LOOP call
 */
void
loop()
{
    // Read from electronics, prevent racing conditions
    noInterrupts();
    readButton = digitalRead(0);// 0 or 1
    potValue = analogRead(A0);// An integer value from 0 to 1023
    interrupts();

    /******* Button press *******/
    // Check if we are pressing the button
    if (readButton == 1)
    {
        pressingButton = true;
    }
    else
    {
        if (pressingButton)
        {
            // The button is not pressed, but we were pressing (i.e. just released the button)
            pressingButton = false;
            selectedFilterId = (selectedFilterId + 1) % 4;
        }
    }

    /******* Potentiometer *******/
    // Project that value onto the 20-20k audible spectrum
    freqPot = (float)potValue * (20000. - 20.) / 1023. + 20.;
    // Update the filter freq from the current potentiometer value
    switch (selectedFilterId)
    {
    case 0:// Low Pass
        myDsp.biquad.setResonLp(freqPot, 10., 0.5);
        break;
    case 1:// High Pass
        myDsp.biquad.setResonHp(freqPot, 10., 0.5);
        break;
    case 2:// Band Pass
        myDsp.biquad.setResonBp(freqPot, 10., 0.5);
        break;
    case 3:// Peak equalizer (here amplifier for the freq, level is positive)
        myDsp.biquad.setPeakEq(10., freqPot, 100.);
        break;
    default:
        Serial.println("Bad filter id, something went wrong...");
    }

    // FFT output (code from `Examples/Audio/Analysis/FFT`)
    if (myFFT.available())
    {
        // each time new FFT data is available
        // print it all to the Arduino Serial Monitor
        // First debug information
        Serial.print("Positive frequency window for f=[0,1.7kHz], Biquad mode=");
        switch (selectedFilterId)
        {
        case 0:
            Serial.print("Lowpass");
            break;
        case 1:
            Serial.print("Highpass");
            break;
        case 2:
            Serial.print("Bandpass");
            break;
        case 3:
            Serial.print("PeakEq");
            break;
        default:
            Serial.print("Unknown");
        }
        Serial.print(", potValue=");
        Serial.print(potValue);
        Serial.print(", fc=");
        Serial.print(freqPot, 0);// No digits
        Serial.println();
        // Start to plot stuff about the FFT
        Serial.println("f(Hz): 0                             250                          500                          750                           1k                                                     1.5k");
        // 500Hz: block index 13
        // 1kHz : block index 23
        Serial.print(" FFT : ");
        for (int i=0; i<n_bins; ++i)
        {
            const double n = myFFT.read(i);
            if (n >= 0.005)
            {
                Serial.print(n, 2);
                Serial.print(" ");
            }
            else
            {
                Serial.print("  -  "); // don't print "0.00"
            }
        }
        Serial.println();
    }
}

